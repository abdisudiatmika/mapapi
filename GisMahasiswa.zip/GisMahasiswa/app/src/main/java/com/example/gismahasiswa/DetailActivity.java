package com.example.gismahasiswa;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class DetailActivity extends AppCompatActivity {
TextView tvalamat,tvnama;
public static  String nama,alamat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        tvalamat=findViewById(R.id.txtalamat);
        tvnama=findViewById(R.id.txtnama);

        tvalamat.setText(alamat);
        tvnama.setText(nama);

    }
}